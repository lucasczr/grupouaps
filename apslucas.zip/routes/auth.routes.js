import React, { } from 'react';

import Login from '../pages/Login'


const AuthRoutes = () => {
  return (
    <Login />
  )
}

export default AuthRoutes;